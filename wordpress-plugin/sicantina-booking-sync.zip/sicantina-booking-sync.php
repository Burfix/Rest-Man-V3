<?php
/**
 * Plugin Name:       Si Cantina Booking Sync
 * Plugin URI:        https://sicantinasociale.co.za
 * Description:       Syncs new bookings from Restaurant Table Bookings (RTB) to the Si Cantina concierge dashboard instantly.
 * Version:           2.0.0
 * Author:            Si Cantina Sociale
 * License:           MIT
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// Settings page
// ============================================================

add_action( 'admin_menu', function () {
    add_options_page(
        'Si Cantina Booking Sync',
        'Cantina Booking Sync',
        'manage_options',
        'sicantina-sync',
        'sicantina_settings_page'
    );
} );

add_action( 'admin_init', function () {
    register_setting( 'sicantina_sync', 'sicantina_api_url',       [ 'sanitize_callback' => 'esc_url_raw' ] );
    register_setting( 'sicantina_sync', 'sicantina_api_key',       [ 'sanitize_callback' => 'sanitize_text_field' ] );
    register_setting( 'sicantina_sync', 'sicantina_sync_new_only', [ 'sanitize_callback' => 'absint' ] );
} );

function sicantina_settings_page() { ?>
<div class="wrap">
    <h1>Si Cantina Booking Sync</h1>
    <p>Automatically forwards every new <strong>Restaurant Table Bookings (RTB)</strong> submission to your concierge dashboard the moment a guest books online.</p>
    <form method="post" action="options.php">
        <?php settings_fields( 'sicantina_sync' ); ?>
        <table class="form-table">
            <tr><th scope="row">Dashboard API URL</th><td>
                <input type="url" name="sicantina_api_url"
                    value="<?php echo esc_attr( get_option('sicantina_api_url') ); ?>"
                    class="regular-text"
                    placeholder="https://yourdomain.com/api/bookings/import" />
                <p class="description">Your deployed dashboard URL + <code>/api/bookings/import</code><br>Example: <code>https://sicantina-dashboard.vercel.app/api/bookings/import</code></p>
            </td></tr>
            <tr><th scope="row">API Secret Key</th><td>
                <input type="password" name="sicantina_api_key"
                    value="<?php echo esc_attr( get_option('sicantina_api_key') ); ?>"
                    class="regular-text" />
                <p class="description">Copy <code>IMPORT_API_KEY</code> from your server's <code>.env.local</code>.</p>
            </td></tr>
            <tr><th scope="row">Sync behaviour</th><td>
                <label><input type="checkbox" name="sicantina_sync_new_only" value="1"
                    <?php checked( 1, get_option('sicantina_sync_new_only', 1) ); ?> />
                    Only sync each RTB booking <strong>once</strong> (on first creation)
                </label>
                <p class="description">Recommended — prevents duplicate entries when staff change a booking status in RTB.</p>
            </td></tr>
        </table>
        <?php submit_button( 'Save Settings' ); ?>
    </form>
    <hr>
    <h2>Connection Test</h2>
    <?php if ( isset($_GET['sicantina_test']) && check_admin_referer('sicantina_test') ) :
        $result = sicantina_send_booking([
            'customer_name' => 'Test User',
            'phone_number'  => '+27000000000',
            'booking_date'  => date('Y-m-d', strtotime('+7 days')),
            'booking_time'  => '19:00',
            'guest_count'   => 2,
            'special_notes' => 'Connection test from WordPress plugin.',
        ]);
        if ( is_wp_error($result) ) :
            echo '<div class="notice notice-error inline"><p><strong>Error:</strong> ' . esc_html($result->get_error_message()) . '</p></div>';
        else :
            echo '<div class="notice notice-success inline"><p><strong>Success!</strong> Reservation ID: <code>' . esc_html($result['reservation_id'] ?? 'n/a') . '</code></p></div>';
        endif;
    endif; ?>
    <p><a href="<?php echo esc_url(wp_nonce_url(add_query_arg('sicantina_test','1'),'sicantina_test')); ?>" class="button button-secondary">Send Test Booking</a></p>
    <hr>
    <h2>Recent Sync Log</h2>
    <?php
    $log = get_option('sicantina_sync_log', []);
    if ( empty($log) ) {
        echo '<p class="description">No bookings synced yet.</p>';
    } else {
        echo '<table class="widefat striped"><thead><tr><th>Time</th><th>RTB ID</th><th>Guest</th><th>Date</th><th>Result</th></tr></thead><tbody>';
        foreach ( array_reverse($log) as $entry ) {
            $c = $entry['ok'] ? 'green' : 'red';
            printf('<tr><td>%s</td><td>#%s</td><td>%s</td><td>%s</td><td style="color:%s">%s</td></tr>',
                esc_html($entry['time'] ?? ''), esc_html($entry['rtb_id'] ?? ''),
                esc_html($entry['name'] ?? ''), esc_html($entry['date'] ?? ''), $c,
                esc_html($entry['ok'] ? 'OK — '.($entry['reservation_id']??'') : 'Error: '.($entry['error']??'')));
        }
        echo '</tbody></table>';
        echo '<p><a href="'.esc_url(wp_nonce_url(add_query_arg('sicantina_clear_log','1'),'clear_log')).'" class="button button-small">Clear Log</a></p>';
    }
    if ( isset($_GET['sicantina_clear_log']) && check_admin_referer('clear_log') ) {
        delete_option('sicantina_sync_log');
        wp_redirect(remove_query_arg(['sicantina_clear_log','_wpnonce'])); exit;
    }
    ?>
</div>
<?php }

// ============================================================
// Core: send booking to dashboard API
// ============================================================

function sicantina_send_booking( array $data ) {
    $url = get_option( 'sicantina_api_url', '' );
    $key = get_option( 'sicantina_api_key', '' );

    if ( empty($url) || empty($key) ) {
        return new WP_Error( 'not_configured', 'Si Cantina Sync: API URL or Key not set. Go to Settings -> Cantina Booking Sync.' );
    }

    $response = wp_remote_post( $url, [
        'timeout'     => 20,
        'headers'     => [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $key,
        ],
        'body'        => wp_json_encode( $data ),
        'data_format' => 'body',
    ] );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code < 200 || $code >= 300 ) {
        $msg = isset($body['error']) ? $body['error'] : "HTTP $code";
        return new WP_Error( 'api_error', $msg );
    }

    return $body;
}

// ============================================================
// RTB hook — fires after every booking is saved/updated
// ============================================================

add_action( 'rtb_booking_post_save', function ( $booking ) {

    // Skip if already synced and "new only" mode is on
    if ( (int) get_option('sicantina_sync_new_only', 1) &&
         get_post_meta( $booking->ID, '_sicantina_synced', true ) ) {
        return;
    }

    // ── Date & time ────────────────────────────────────────────────────────
    $booking_date = '';
    $booking_time = '';
    if ( ! empty( $booking->date ) ) {
        if ( $booking->date instanceof DateTime ) {
            $booking_date = $booking->date->format('Y-m-d');
            $booking_time = $booking->date->format('H:i');
        } else {
            $ts = strtotime( (string) $booking->date );
            if ( $ts ) {
                $booking_date = date('Y-m-d', $ts);
                $booking_time = date('H:i',   $ts);
            }
        }
    }

    // ── Phone ──────────────────────────────────────────────────────────────
    $phone = ! empty($booking->phone)
        ? (string) $booking->phone
        : (string) get_post_meta($booking->ID, 'rtb-phone', true);
    $phone = preg_replace('/\s+/', '', $phone);
    // Convert 10-digit SA number to E.164
    if ( preg_match('/^0[6-8][0-9]{8}$/', $phone) ) {
        $phone = '+27' . substr($phone, 1);
    }
    if ( empty($phone) ) $phone = 'website-no-phone';

    // ── Payload ────────────────────────────────────────────────────────────
    $guest_count = ! empty($booking->party) ? (int) $booking->party : 1;
    $notes_parts = [];
    if ( ! empty($booking->request) ) $notes_parts[] = $booking->request;
    $notes = implode("\n", $notes_parts);

    $data = [
        'customer_name' => sanitize_text_field( $booking->name ?? '' ),
        'phone_number'  => $phone,
        'booking_date'  => $booking_date,
        'booking_time'  => $booking_time,
        'guest_count'   => $guest_count,
    ];
    if ( ! empty($booking->email) ) $data['customer_email'] = sanitize_email( $booking->email );
    if ( $notes ) $data['special_notes'] = sanitize_textarea_field($notes);

    if ( ! $data['customer_name'] || ! $booking_date || ! $booking_time ) {
        error_log("[SiCantina] Skipped RTB #{$booking->ID} — missing required fields.");
        return;
    }

    // ── Send ───────────────────────────────────────────────────────────────
    $result = sicantina_send_booking($data);

    // ── Log ────────────────────────────────────────────────────────────────
    $log   = get_option('sicantina_sync_log', []);
    $entry = [
        'time'   => current_time('Y-m-d H:i:s'),
        'rtb_id' => $booking->ID,
        'name'   => $data['customer_name'],
        'date'   => $booking_date,
    ];
    if ( is_wp_error($result) ) {
        $entry['ok']    = false;
        $entry['error'] = $result->get_error_message();
        error_log("[SiCantina] Sync error RTB #{$booking->ID}: " . $result->get_error_message());
    } else {
        $entry['ok']             = true;
        $entry['reservation_id'] = $result['reservation_id'] ?? '';
        update_post_meta($booking->ID, '_sicantina_synced',         1);
        update_post_meta($booking->ID, '_sicantina_reservation_id', $entry['reservation_id']);
    }
    $log[] = $entry;
    if ( count($log) > 50 ) $log = array_slice($log, -50);
    update_option('sicantina_sync_log', $log);

}, 20 );

// ============================================================
// Show sync badge on the RTB booking edit screen
// ============================================================

add_action('add_meta_boxes', function () {
    add_meta_box(
        'sicantina_sync_status', 'Dashboard Sync',
        function ($post) {
            $synced = get_post_meta($post->ID, '_sicantina_synced', true);
            $res_id = get_post_meta($post->ID, '_sicantina_reservation_id', true);
            if ($synced) {
                echo '<p style="color:green;margin:0">&#10003; Synced to dashboard</p>';
                echo '<p style="color:#888;font-size:11px;margin:4px 0 0">ID: <code>' . esc_html($res_id) . '</code></p>';
            } else {
                echo '<p style="color:#999;margin:0">&#10007; Not yet synced</p>';
            }
        },
        'rtb-booking', 'side', 'low'
    );
});
